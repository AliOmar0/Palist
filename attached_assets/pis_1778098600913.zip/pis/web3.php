<div id="back_col">
<div id="web2">
		<div class="w1200">
		
			
			<div id="footer">
			
					<div id="foot_about" class="w30 in">
				

			<div class="parent">
				<div class="child">
					
				<?php if(curr() == "ar"){ 
								pic(c('ar_logo','photo'),1000,100,l($settings['site_name']),true,'logo_menu','mid');

				}else{
					pic($settings['logo'],1000,100,l($settings['site_name']),true,'logo_menu','mid');

				}?>
				
					<p><?=cl('footer','text')?></p>
									
				</div>
			</div>

		</div><!--
	
		--><div id="footer_content" class="w50 mid">
				
						
			<ul class="footer_ul in w40">
<!--<?php
$resp=db('menu_items_1564508835','WHERE menu_key=15 AND deleted=0 AND sub_of=0','ORDER BY order_num ASC');
if($resp==0)  echo 'error';
else if($resp==1) echo 'No Data';
else { for($i=0;$i<count($resp);$i++){?>
--><li class="noselect menu_items_box in ">
	<a class="foot_a" target="<?= $resp[$i]['open_new_window']==0 ? '_self':'_blank';?>" <?php if(linker($resp[$i])!='noLink'){?> href="<?= linker($resp[$i]);?>" <?php }?> title="<?= l(menuTitle($resp[$i]));?>">
		<?= l(menuTitle($resp[$i]));?>
    </a>
				
					</li><!--
<?php 
    }//for
}//else
unset($resp);?>
-->
					
  </ul>

  <ul class="footer_ul in w40">
<!--<?php
$resp=db('menu_items_1564508835','WHERE menu_key=16 AND deleted=0 AND sub_of=0','ORDER BY order_num ASC');
if($resp==0)  echo 'error';
else if($resp==1) echo 'No Data';
else { for($i=0;$i<count($resp);$i++){?>
--><li class="noselect menu_items_box in ">
	<a class="foot_a" target="<?= $resp[$i]['open_new_window']==0 ? '_self':'_blank';?>" <?php if(linker($resp[$i])!='noLink'){?> href="<?= linker($resp[$i]);?>" <?php }?> title="<?= l(menuTitle($resp[$i]));?>">
		<?= l(menuTitle($resp[$i]));?>
    </a>
				
					</li><!--
<?php 
    }//for
}//else
unset($resp);?>
-->
					
  </ul>

</div><!--

--><div id="social_links_wrap" class="w20 social_align in">
			<!--<?php
			$_m='social_links_8363';
			$resp=db($_m,NULL,NULL);
			if($resp==1) echo 'No Data';
			else { for($i=0;$i<count($resp);$i++){?>
			--><a class="social_links_box social in"  title="<?=l($resp[$i]['title']) ?>" href="<?=$resp[$i]['link']?>" target="_blank">
					<?=$resp[$i]['social_font']?>
				</a><!--
			<?php 
				}//for
			}//else
			unset($resp);?>
			-->
		</div>

				
			</div>
			
	
		
	</div>
	
</div>

		</div>