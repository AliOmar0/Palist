if($.isFunction($.fn.select2)){
	$(document).ready(function(){
		$(function(){
		  $("select").not('.noSelect2').select2();
		});
	});
}



if($.isFunction($.fn.nestedSortable)){
$(document).ready(function(){
		$('.sortable').nestedSortable({
			handle: 'div',
			items: 'li',
			toleranceElement: '> div',
			update: function(event,ui){
				if(typeof sort_save==="function"){
					sort_save();
				}
			},
		});
	});
}

$(document).ready(function(){
	$.ajaxSetup({cache: false});
	$.ajaxSetup({async: true});
});

function init(){
	var vidDefer = document.getElementsByTagName('iframe');
	for(i=0;i<vidDefer.length;i++){
	if(vidDefer[i].getAttribute('data-src')){
	vidDefer[i].setAttribute('src',vidDefer[i].getAttribute('data-src'));
	}
	} 
}

window.addEventListener("load",init,false);