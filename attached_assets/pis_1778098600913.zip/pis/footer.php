
</main>
<?php if(!isset($_GET['mobile'])){?>
<?php require 'web3.php'?>
<footer>

	<div  id="final">
	<div class="w1200"><!--
	
	--><div id="right" class="w50 mid">
 &copy;	<?= date('Y');?> <?= l($settings['site_name']);?> 
	</div><!--
	
	--><div  id="provision" class="w50 mid"> 
		
			<?php
	$url = $legion['provision']['logo_medium'];
$img = 'uploads/provision.png';
if(!file_exists($img))
	file_put_contents($img, file_get_contents($url));
	?>
			<a  href="<?= $legion['provision']['link'];?>" target="_blank" title="Design & Development by <?= $legion['provision']['name'];?>">
				<div id="pv_inside" >
				<?php if(get_lang_direction()=='ltr'){?>
				<span class="mid"><span id="design">d</span>esign
					&
					<span id="dev">d</span>evelopment</span>
				<clear></clear>
				<div class="mid">
					<img  src="<?= uploads_link.img('provision_logo_web.png',140,100);?>" alt="<?= $legion['provision']['name'];?>"/>
					
					
					</div>
				<?php } else { ?>
				<span class="mid">تصميم
					و
					تطوير</span>
				<div class="mid">
					<img src="<?= uploads_link.img('provision_logo_web.png',140,100);?>" alt="<?= $legion['provision']['name'];?>"/>
					
					</div>
				<?php }?>
				
				</div>
				
			</a>
		</div>
	
</div>
		</div>
</footer>
<?php }

require 'legion_footer.php';