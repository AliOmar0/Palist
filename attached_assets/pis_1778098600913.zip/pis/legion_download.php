<?php
require 'panel/core/config.php';

$filename=escape($_GET['file']);

$x=explode('.',$filename);

if(str_contains($x[0],'H')){
	$x[0]=explode('H',$x[0])[1];
}

$file=o('files_1577206823',$x[0],'name');
$file_path=_protected.$filename;


function show($good=true){
	global $file_path,$file;
	if(!$good){
		$file_path=target_dir.'noPermission.png';
		$file=array(array('original_name'=>'No Permission'));
	}
}

function canDownload(){
	global $file;
	if(isLogged())return true;
	if(!isset($_SESSION['user_id']) || !isset($_SESSION['module_id']))return false;
	if($file[0]['uploader_module_prefix']==$_SESSION['module_id'] && $file[0]['uploader_user_id']==$_SESSION['user_id'])return true;
	if($file[0]['related_module']==$_SESSION['module_id'] && $file[0]['related_module_id']==$_SESSION['user_id'])return true;
	return false;
}


if($file!=1 && file_exists($file_path) && canDownload()){
	
}else show(false);

header('Content-type:'.mime_content_type($file_path));
header('Content-Length:'.filesize($file_path));
header('Content-Disposition:attachment;filename='.$file[0]['original_name']);
readfile($file_path);
exit();