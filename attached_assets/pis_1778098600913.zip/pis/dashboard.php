

<?php
$_user='users_8400';


if(isLogged(moduleID($_user))){
	?>

<div class="l_grid2" id="dashboard_wrap">
<a class="dashboard_item" href="<?=url('pages_1478423482','single','edit-profile')?>">
	<span class="midinline"><?=l('Edit profile<>تعديل معلومات الحساب')?></span>	
	<i class="dashboard_item_icon">expand_circle_down</i>
	</a>


<a class="dashboard_item" href="<?=url('pages_1478423482','single','change-password')?>"><span class="midinline"><?=l('Change Password<>تغيير كلمة المرور')?></span>
<i class="dashboard_item_icon">expand_circle_down</i>
</a>
<?php
// $resp_u=db($_user,"WHERE !deleted and user=".$_SESSION['user_id'],NULL);
$resp_j=db('joining_request_form_8371',"WHERE !deleted and user=".$_SESSION['user_id'],NULL);

if($resp_j[0]['active']== 1 && $resp_j[0]['submitted']== 1){
?>
<a class="dashboard_item" href="<?=urlp('joining-request-form')?>">	<i class=""></i>
	<span class="midinline"><?=l('Edit Membership Info.<>تعديل معلومات العضوية. ')?></span>
	<i class="dashboard_item_icon">expand_circle_down</i>
</a>

<?php
}else{
?>
<a class="dashboard_item" href="<?=urlp('joining-request-form')?>"><i class=""></i>
	<span class="midinline"><?=l('Joining Request form<>طلب انتساب')?></span>
	<i class="dashboard_item_icon">expand_circle_down</i>
</a>
<?php } ?>
<a class="dashboard_item" href="<?=urlPanel.'logout.php?location='.url?>" title="<?=l('Logout<>تسجيل خروج')?>">
	<span class="mid"><?=l('Logout<>تسجيل خروج')?></span>
	<i class="dashboard_item_icon">expand_circle_down</i>
</a>

</div>

<div class="add_height"></div>

<?php
	
}else{
	goSign();
}
