<?php
if(logged(mid($_user)) ){

    ?>
    <script>
        window.location.href="<?=urlp('dashboard')?>";
    </script>

    <?php
}else{

?>
     <div id="login_wrap" class="w1200">
      
    <form  id="c_users_8400" autocomplete="off" action="" onsubmit="return submitter(this,'<?php if(isset($controllerURL))echo $controllerURL;else echo urlPanel;?>');" method="post" enctype="multipart/form-data">
        
       
        
    <input type="hidden" value="" name="e"/>
    <input type="hidden" name="module" value="users_8400"/> 
    <input type="hidden" name="c_login" value="<?= rand()?>"/>
    
    <input type="hidden" name="lang" value="<?=curr()?>"/>
    
    <!--inputs below --> 
    <!--
        
    
        --><div class="form_field users_8400_email_address">
    <label for="for_field_email"><?= l('Email<>البريد الاكلتروني');?> <span class="required_star">*</span></label>
    <div class="input_area">
    <input id="for_field_email"  required type="email" name="email_address" placeholder="<?= l('Email<>البريد الاكلتروني');?>" value=""/>
    </div>
    </div><!--
    
    --><div class="form_field users_8400_password">
    <label for="for_field_password"><?= l('Password<>الرقم السري');?> <span class="required_star">*</span></label>
    <div class="input_area">
      <a id="eye_icon" class="po" onclick="myFunction()"> <i>visibility_off</i></a>
    <input id="for_field_password" required  type="password" name="password" placeholder="<?= l('Password<>الرقم السري');?>" value=""/>
    </div>
    </div><!--  
    -->      
        
        <input type="submit" value="<?= l('Login<>تسجيل الدخول')?>" class="b"/>
        
        <m20></m20>
            <a class="have_account" href="<?= url('pages_1478423482','single','signup')?>" title="<?= l(detail('pages_1478423482','title','slug','signup'))?>" >
                        <span class="midinline"><?= l('No account? Signup<>لا يوجد حساب؟ اعمل جديد')?></span>
                    </a>
                    <div class="w90"></div>
        		<div onClick="forgot()" class="pointer forgot"><?=l('Frogot Password<>نسيت كلمة المرور' )?></div>

        
    <!--inputs above -->
    </form>
    
    <div id="forget" style="display: none;">
					<form  id="inner" autocomplete="off" action="" onsubmit="return submitter(this,'<?php if(isset($controllerURL))echo $controllerURL;else echo urlPanel;?>');" method="post" enctype="multipart/form-data">
            <input type="hidden" value="" name="e"/>
            <input type="hidden" value="true" name="c_forgot"/>
              
						
						<div class="form_field users_1627035922_email_address">
							<label for="for_field_email_address">Email Address</label>
							<div class="input_area">
							<input id="for_field_email_address" type="email" name="email_address" placeholder="Email Address" value="">
							</div>
						</div>
						
						<input type="submit" class="btn" value="<?=l('Send New Password<>ارسال كلمة سرية جديدة')?>"/>

				</form>
			</div>
 
    <div id="c_successLogin" class="hidden">
    <?= l('Your signin was successful, you will be redericted to the home page<>تم عمل الحساب، جاري تحويل الصفحة.. ')?>
        
    </div>

    <div id="pop_box" style="display:none">
       <h2>   <?= l('You are suspended<>حسابك معلق')?></h2>
       <i class="material_icons cancel po" onclick="closeForm()">cancel</i>
    </div>
                    
           </div>

 
    
           <div class="add_height"></div>
    
    <script>
        
    
    function successLogin(data,params){
        hide('users_8400');
        show('c_successLogin');
        redirect(data,params);
    }


    function popError(){
      $('#pop_box').show();
    }

    function closeForm(){
      $('#pop_box').hide();

    }
  //   function s(what){
	// 	if(what=='up'){
	// 		show('signup_wrap');
	// 		hide('signin_wrap');z
	// 		$('.upp').addClass('ac');
	// 		$('.inn').removeClass('ac');
	// 		hide('forget');
	// 	}else if(what=='forgot'){
	// 		hide('signup_wrap');
	// 		hide('signin_wrap');
	// 		$('.upp').removeClass('ac');
	// 		$('.inn').removeClass('ac');
	// 		show('forget');
	// 	}else{
	// 		hide('signup_wrap');
	// 		show('signin_wrap');
	// 		$('.inn').addClass('ac');
	// 		$('.upp').removeClass('ac');
	// 		hide('forget');
	// 	}
	// }
  function forgot(){
    $('#c_users_8400').hide();
    $('#forget').show();
  }

  function c_forgot_func(){
    window.location.href='<?=urlp('dashboard')?>';// redirect
  }
    </script>



<script>
function myFunction() {
  var x = document.getElementById("for_field_password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>


<?php }?>