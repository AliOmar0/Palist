<?php
//ProVision is the best
		if(strpos($uri,'/trainings_and_workshops/')!==false){
			$post['title']=mn('trainings_and_workshops_8419');
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].l($post['title']);
			
		}
		else if(strpos($uri,'/training_and_workshop/')!==false){
			$post=db('trainings_and_workshops_8419',"WHERE id='$indicator' ",NULL,"LIMIT 1")[0];
			$post['title']=l($post['title']);
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].$post['title'];
			$metaArray['desc']=sl($post['content']);}
		
		else if(strpos($uri,'/other_laws/')!==false){
			$post['title']=mn('other_laws_8419');
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].l($post['title']);
			
		}
		else if(strpos($uri,'/law/')!==false){
			$post=db('other_laws_8419',"WHERE id='$indicator' ",NULL,"LIMIT 1")[0];
			$post['title']=l($post['title']);
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].$post['title'];
			$metaArray['desc']=sl($post['']);}
		
		else if(strpos($uri,'/members/')!==false){
			$post['title']=mn('members_8364');
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].l($post['title']);
			
		}
		else if(strpos($uri,'/single_member/')!==false){
			$post=db('members_8364',"WHERE id='$indicator' ",NULL,"LIMIT 1")[0];
			$post['title']=l($post['name']);
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].$post['title'];
			$metaArray['desc']=sl($post['job_name']);
			if($post['photo']!='')$metaArray['image']=u.$post['photo'];}
		
		else if(strpos($uri,'/page/')!==false){
			$post=db('pages_1478423482',"WHERE slug='$indicator'  OR id='$indicator'",NULL,"LIMIT 1")[0];
			$post['title']=l($post['title']);
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].$post['title'];
			$metaArray['desc']=sl($post['content']);
			if($post['photo']!='')$metaArray['image']=u.$post['photo'];}
		
		else if(strpos($uri,'/internal_system/')!==false){
			$post['title']=mn('internal_system_8367');
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].l($post['title']);
			
		}
		else if(strpos($uri,'/join_us/')!==false){
			$post['title']=mn('join_us_8367');
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].l($post['title']);
			
		}
		else if(strpos($uri,'/publications/')!==false){
			$post['title']=mn('publications_8367');
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].l($post['title']);
			
		}
		else if(strpos($uri,'/videos/')!==false){
			$post['title']=mn('video_gallery_8367');
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].l($post['title']);
			
		}
		else if(strpos($uri,'/announcements/')!==false){
			$post['title']=mn('advertisements_8362');
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].l($post['title']);
			
		}
		else if(strpos($uri,'/single-announce/')!==false){
			$post=db('advertisements_8362',"WHERE id='$indicator' ",NULL,"LIMIT 1")[0];
			$post['title']=l($post['title']);
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].$post['title'];
			$metaArray['desc']=sl($post['content']);
			if($post['photo']!='')$metaArray['image']=u.$post['photo'];}
		
		else if(strpos($uri,'/events/')!==false){
			$post['title']=mn('events_8362');
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].l($post['title']);
			
		}
		else if(strpos($uri,'/event/')!==false){
			$post=db('events_8362',"WHERE id='$indicator' ",NULL,"LIMIT 1")[0];
			$post['title']=l($post['title']);
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].$post['title'];
			$metaArray['desc']=sl($post['events_description']);
			if($post['photo']!='')$metaArray['image']=u.$post['photo'];}
		
		else if(strpos($uri,'/programs/')!==false){
			$post['title']=mn('programs_and_training_8366');
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].l($post['title']);
			
		}
		else if(strpos($uri,'/single-program/')!==false){
			$post=db('programs_and_training_8366',"WHERE id='$indicator' ",NULL,"LIMIT 1")[0];
			$post['title']=l($post['title']);
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].$post['title'];
			$metaArray['desc']=sl($post['content']);
			if($post['photo']!='')$metaArray['image']=u.$post['photo'];}
		
		else if(strpos($uri,'/photos_albums/')!==false){
			$post['title']=mn('photos_library__8366');
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].l($post['title']);
			
		}
		else if(strpos($uri,'/photos/')!==false){
			$post=db('photos_library__8366',"WHERE id='$indicator' ",NULL,"LIMIT 1")[0];
			$post['title']=l($post['title']);
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].$post['title'];
			
			if($post['cover_photo']!='')$metaArray['image']=u.$post['cover_photo'];}
		
		else if(strpos($uri,'/news/')!==false){
			$post['title']=mn('news_8362');
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].l($post['title']);
			
		}
		else if(strpos($uri,'/single-news/')!==false){
			$post=db('news_8362',"WHERE id='$indicator' ",NULL,"LIMIT 1")[0];
			$post['title']=l($post['title']);
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].$post['title'];
			$metaArray['desc']=sl($post['content']);
			if($post['photo']!='')$metaArray['image']=u.$post['photo'];}
		
		else if(strpos($uri,'/about_us/')!==false){
			$post['title']=mn('about_the_syndicate_8362');
			$metaArray['title']=$metaArray['title'].$metaArray['sep'].l($post['title']);
			
		}