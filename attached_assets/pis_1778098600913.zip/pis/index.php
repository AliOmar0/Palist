<?php $is_home=true;require 'header.php';?>

<mh></mh>
<link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css"/>

<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>

<div class="home">
<?php
include 'slider.php'?>
</div>
<div onclick="topFunction()" id="myBtn"  ><!-- id="icon_box" onClick="scrollToTop()" -->
	<i class="arrow_up_icon po">keyboard_arrow_up</i>
</div>

	<section class=" about_wrap">
		<?php $_m='about_the_syndicate_8362';$i=0;?>
	
	
		<!--<?php
		$resp=db($_m,NULL,NULL);
		if($resp==1) echo '<div class="no_data">'.l('No Data<>لا مُدخلات').'</div>';
		else { for($i=0;$i<count($resp);$i++){?>
		--><div class="about_the_syndicate_box" title="<?=l($resp[$i]['title']) ?>">
		<div class="w1200">
			<div class="w50 in about_us_left">
			<h1 class="about_the_syndicate_title"><a title="<?=mn($_m)?>" href="<?=url($_m)?>"><?=l('About <>نبذة')?></a></h1>
			<h1 class="about_the_syndicate_subtitle"><a title="<?=mn($_m)?>" href="<?=url($_m)?>"><?=l('The Syndicate <>عن النقابة')?></a></h1>
			<!-- <h2 class="about_the_syndicate_title"><?=l($resp[$i]['title']);?></h2> -->
				<div class="about_the_syndicate_summary"><?=l($resp[$i]['summary']);?></div>
				<div class="about_btn">
					<a  href="<?=url($_m)?>"><?=l('Read more <> اقرأ المزيد')?></a>
				</div>
			</div><!--
			--><div class="w45 mid about_us_right">
				<div class="about_right_bg"></div>
				<?php pic($resp[$i]['photo'],1000,800,l($resp[$i]['title']),true,NULL,'about_the_syndicate_photo_picture');?>
			</div>
		</div>
		</div><!--
		<?php 
		}//for
		}//else
		unset($resp);?>
		-->
</section>

<section id="news_wrap" class="major_section w1200">
		<?php $_m='news_8362';?>
		<div class="line_box">
				<div class="title_line mid"></div><!--
				--><h1 id="news_header" class="mid"><a title="<?=mn($_m)?>" href="<?=url($_m)?>"><?=l('Latest News<>أخر أخبارنا')?></a></h1>
				<a href="<?=url($_m)?>"><i class="mid">arrow_forward</i></a>
			</div>
			
	
	<div class="l_grid3" id="n_wrap">	
		<!--<?php
		$resp=db($_m,NULL,'ORDER BY publish_date DESC',"limit 6");
		if($resp==1) echo '<div class="no_data">'.l('No Data<>لا مُدخلات').'</div>';
		else { for($i=0;$i<count($resp);$i++){?>
		<?php if($resp[$i]['photo'] !=NULL){?>
	--><a class="other_news in" title="<?=l($resp[$i]['title']) ?>" href="<?=url($_m,'single',$resp[$i]['id'])?>">
				<div class="news_left  in">
					<?php pic($resp[$i]['photo'],400,100,l($resp[$i]['title']),true,NULL,'other_news_photo_picture');?>
				</div><!--
				--><div class="news_right  in">
								<h2 class="other_news_title el"><?=l($resp[$i]['title']);?></h2>
								<div class =" news_info">
									<h2 class="news_publish_date in w50"><?=l($resp[$i]['publish_date']);?></h2><!--
		--><h2 id="more" class="in w50 news_publish_date"><?=l('More ...<>  المزيد...')?></h2>
								</div>
					</div>
			</a><!--
			<?php	}?>
		<?php 
			}//for
		}//else
		unset($resp);?>
		-->
		</div>		
		
</section>		

<div class="w1200" id="events_and_advertisements">
	<?php $_m='events_8362';?>

	<section id="events_wrap" class="">
		<div class="line_box">
	<div class="title_line mid"></div><!--
	--><h1 id="news_header" class="mid"><?=l("The Syndicate's Activities<>فعاليات النقابة")?></h1>
	<a href="<?=url($_m)?>"><i class="mid">arrow_forward</i></a>
	</div>
	<div class="event_wrap_box">
	<div class="events_wrap_left mid w50">
		<?php include 'calender.php'?>
	</div><!--
			--><div class="events_wrap_right mid w35">
			<?php $_m='events_8362';?>
			
						<!--<?php
						$resp=db($_m,NULL,NULL,"limit 1");
						if($resp==1) echo '<div class="no_data">'.l('No Data<>لا مُدخلات').'</div>';
						else { for($i=0;$i<count($resp);$i++){?>
						--><div class="events_box in" title="<?=l($resp[$i]['title']) ?>" href="<?=url($_m,'single',$resp[$i]['id'])?>">
							<?php pic($resp[$i]['photo'],400,100,l($resp[$i]['title']),true,NULL,'events_photo_picture');?>
							<div class="events_content_box">
							<h2 class="events_title in"><?=l($resp[$i]['title']);?></h2>
								<div class="events_date_box">
								<div class="events_date in w50 "><?=$resp[$i]['event_date']?></div><!--
								--><a href="<?=url($_m,'single',$resp[$i]['id'])?>" class="events_read_more in w50 "><?=l('Read More ...<> اقراء المزيد ...')?></a>
									
									</div>
							</div>
						</div><!--
						<?php 
						}//for
						}//else
						unset($resp);?> 
						-->
				</div>
				<!-- <div class=" events_btn" ><a href="<?=url($_m)?>"><?=l('Read more <> اقراء المزيد');?></a></div> -->
					</div>
	</section>
</div>
			

<section id="advertisements_wrap" class=" w1200">
<?php $_m='advertisements_8362';?>
<div class="line_box">
<div class="title_line mid"></div><!--
	-->	<h1 id="news_header" class="mid"><a title="<?=mn($_m)?>" href="<?=url($_m)?>"><?=l("The Syndicate's Announcements<>اعلانات النقابة")?></a></h1>
	<a href="<?=url($_m)?>"><i class="mid">arrow_forward</i></a>
</div>

<div class="l_grid3">
			<!--<?php
			$resp=db($_m,NULL,NULL,"limit 3");
			if($resp==1) echo '<div class="no_data">'.l('No Data<>لا مُدخلات').'</div>';
			else { for($i=0;$i<count($resp);$i++){?>
			--><div class="advertisements_box in" title="<?=l($resp[$i]['title']) ?>" >
				<?php pic($resp[$i]['photo'],400,100,l($resp[$i]['title']),true,NULL,'advertisements_photo_picture');?>
				<h2 class="advertisements_title"><?=l($resp[$i]['title']);?></h2>
				<div class="more_btn_adv">
						<a href="<?=url($_m,'single',$resp[$i]['id'])?>" class="in"><?=l('More > <>المزيد >')?></a>
					</div>
				<!-- <i class="advertisements_icon">campaign</i> -->

			</div><!--
			<?php 
			}//for
			}//else
			unset($resp);?>
			-->
</div>
</section>
<!-- </div> -->
<div class="join_bg"></div>
<div class="home_join" <?=bg(c('join','photo'));?>>
	<div class="w1200">
			<div class="home_join_title"><?=cl('Join','title')?></div>
			<div class="home_join_text"><?=cl('Join','text')?></div>
			<div class="home_join_formatted_text"><?=cl('Join','formatted_text')?></div>
			<a href="<?=urlp('signin');?>" class="home_join_btn"><?=l('Know More! <> !تعرف أكثر')?></a>
	</div>
</div>
<div class="w1200 contact_box" id="contact_wrap_home">
<div class="line_box">
<div class="title_line mid"></div><!--
	--><h1 class="mid" id="news_header"><?=l('Keep In Touch<>ابقى على تواصل معنا')?></h1>
</div>
	<?php include 'contact_us.php';?>
</div>
<div class="map"><?php include 'offices_block.php';?></div>
<!-- <m20></m20> -->



<script >
// function scrollToTop() {
// 	$('html, body').animate({
//        scrollTop: $('.home').offset().top - 170 
//     }, 'slow');
// }

</script>

<script>
// Get the button
let mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>

<?php 
require 'footer.php';?>