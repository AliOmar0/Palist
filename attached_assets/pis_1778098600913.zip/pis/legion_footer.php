<?= connection('fb_app_analytics');?>
<?= connection('fb_pixel');?>
<div class="hidden">
	<script  src="<?= pres?>js/submitter.js<?php clearCache();?>" defer></script>
	<script src="<?= pres?>js/functions.js<?php clearCache();?>" defer></script>
	<script  src="<?= pres?>js/responser.js<?php clearCache();?>" defer></script>
	<link rel="stylesheet" href="<?= fres?>css/fancybox.css<?php clearCache();?>"  media="none" onload="this.media='all';"/> 
	<script  src="<?= fres?>js/fancybox.js<?php clearCache();?>" defer></script>
	<script  src="<?= fres?>js/aos.js<?php clearCache();?>" defer></script>
	<script>
		$(function(){
			AOS.init({
				easing: 'ease-out-back',
				duration: 1000
			});
		});
	</script>
<!--	<script type="javascript" src="<?= fres?>js/lazyYoutube.js<?php clearCache();?>" defer></script>-->
</div>



<?php if(!isset($_GET['mobile'])){?>
<?php if(!isset($noFacebook) && connection('facebook_page_id')!=NULL){?>

	<!-- Load Facebook SDK for JavaScript -->
      <div id="fb-root"></div>
      <script>
        window.fbAsyncInit = function() {
          FB.init({
            xfbml            : true,
            version          : 'v6.0'
          });
        };

        (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
			
      }(document, 'script', 'facebook-jssdk'));

		  
		   $('#fb-root').bind("DOMSubtreeModified",function(){
      $('iframe').attr('title', 'facebook');
    });
		  
		  
</script>

      <!-- Your customer chat code -->
      <div class="fb-customerchat" attribution=setup_tool theme_color="<?=connection('facebook_chat_color')?>"  page_id="<?=connection('facebook_page_id')?>" greeting_dialog_display="hide">
      </div>
<?php }?>

<?php }?>

<?= connection('sharethis');?>
<?= connection('footer_js');?>


<?php require panel_dir.'sharedFooter.php'?>
</body>
</html>