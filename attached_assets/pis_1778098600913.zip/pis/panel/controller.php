<?php
require('core/config.php');

//dp();
$module=i('module')?e('module'):'';
$action=i('action')?e('action'):'';
//dp();

if($module=='comments' && $action=='add'){
	$_POST['commenter_module']=$_SESSION['module_id'];
	$_POST['commenter_id']=$_SESSION['user_id'];
}

require custom_dir.'custom_controller.php';

//special type, login exceptional,outside the system
if(isset($_POST['type']) && $_POST['type']=='login'){
        require(core_dir.'modules/loginModel.php');
		die();
	}

else if(isset($_GET['viewMod'])){
	$module=isset($_GET['viewMod']) ? eg('viewMod'):NULL;
	$action='edit';
	if($module!=NULL){
	$m=db('module_settings',"WHERE module_prefix='$module'",NULL,"LIMIT 1");
		if($m!=0 || $m!=1){
			$m=$m[0];
	$m['info']=db('modules',"WHERE module_prefix='$module'",NULL,'LIMIT 1')[0];
	$m['module_id']=$m['info']['id'];
		}


	if($action!=NULL && isset($m['module_id']))
		$actionDetails=db('module_actions',"WHERE module_id='".$m['module_id']."' AND type='$action'",NULL,'LIMIT 1')[0];
	
	if(db('module_fields',"WHERE module_id='".mid($module)."' AND type='location'")!=1)$mapHere=true;else $mapHere=false;
		
	if(!privilege($module, $action) && !($module=='admins' && $action=='edit' && $_SESSION['user_id']==$_GET['id']))die(l('No permission<>ليس من صلاحياتك'));
	
	
//	include modules_dir.$_GET['viewMod'].'/views/edit.php';
		 require_once core_dir.'modules/bread.php';
		 require_once modules_dir.$module.'/views/'.$action.'.php';
		require_once core_dir.'preViewFormEnd.php';
        if (detail('modules','ml','module_prefix',$module)==true && $action!='usage') {
            echo "<script>
			var ml_supp_input_names=".json_encode(explode(',',$m['ml_fields'])).";</script>";
            require panel_dir.'core/modules/lang.php';
        }
		
		if($mapHere)include_once core_dir.'modules/map.php';
        echo '</div>';
		
//	echo'<input type="submit" class="btn" value="'.l('Save<>حفظ').'" form="'.$_GET['viewMod'].'"/>';
//	echo'<input type="hidden" name="force_refresh" value="true" form="'.$_GET['viewMod'].'"/>';
	die();
}
	die(l('No permission<>ليس من صلاحياتك'));
}


else if(isset($_GET['addMod'])){
	include modules_dir.$_GET['addMod'].'/views/add.php';
//	if(g('viewMod'))
		echo'<input type="submit" class="btn" value="'.l('Save<>حفظ').'" form="'.$_GET['viewMod'].'"/>';
//	if(g('viewMod'))
		echo'<input type="hidden" name="force_refresh" value="true" form="'.$_GET['viewMod'].'"/>';
	die();
}

else if(g('imagine') && logged()){
	$_GET['imagine']=end(explode('/',$_GET['imagine']));
	include imagine;
//	if(g('viewMod'))
//		echo'<input type="submit" class="btn" value="'.l('Save<>حفظ').'" form="'.$_GET['viewMod'].'"/>';
//	if(g('viewMod'))
//		echo'<input type="hidden" name="force_refresh" value="true" form="'.$_GET['viewMod'].'"/>';
	die();
}


else if(isset($_POST['type']) && $_POST['type']=='select' && isset($_POST['whereKey'])){
	$_POST['db']=e('db');
	

	if((detail('modules','external_access','module_prefix',$_POST['db'])==0 && !privilege($_POST['db'],'list')) && !super())json(false,66);
	$_POST['fields']=e('fields');
	$whereKey=e('whereKey');
	$whereValue=e('whereValue');
	$data=db($_POST['db'],"WHERE $whereKey='$whereValue' AND deleted=0",NULL,NULL,'id,'.$_POST['fields']);
	//legacy start
	if(i('selectNameToRefresh'))
		$selector="select[name^='".$_POST['selectNameToRefresh']."']";
	else
	//legacy end
		$selector=$_POST['selector'];
	
//	d($data);
	if($data==0)json(false,3);
	if($data==1)json(true,1,1,NULL,array('js'=>'reload_options','selector'=>$selector));
	else{
		$exploded=explode(',',$_POST['fields']);
		for($i=0;$i<count($exploded);$i++){
			for($j=0;$j<count($data);$j++){
				$data[$j][$exploded[$i]]=l($data[$j][$exploded[$i]]);
			}
	}
		$arr=array('js'=>'reload_options','selector'=>$selector,'echoValue'=>$_POST['fields']);
		
		$arr['currentValue']=i('currentValue')?$_POST['currentValue']:NULL;
		$arr['clear']=i('clear')?$_POST['clear']:true;
		
		json(true,1,$data,NULL,$arr);
	}
	
	 json(false,3);
	}



#! make private, maybe?
elseif(i('stats_check')){
	$res=[];
	$x=explode(',',$_POST['ids']);
	$y=explode(',',$_POST['box_ids']);
	
	if($x!=false){
		foreach($x as $key=>$id){
			$_stats_big_arr=s_item_data($id);
			if($_stats_big_arr['grand_total']>0 && !empty($_stats_big_arr) && $_stats_big_arr['analytics'][0]['item']['type']=='Chart'){
				$res[]=['type'=>$_stats_big_arr['analytics'][0]['item']['type'],'id'=>$id,'box_id'=>$y[$key],'data'=>$_stats_big_arr['analytics'],'labels'=>$_stats_big_arr['analytics'][0]['labels']];
			}elseif($_stats_big_arr['analytics'][0]['item']['type']=='Count'){
				$res[]=['type'=>$_stats_big_arr['analytics'][0]['item']['type'],'id'=>$id,'box_id'=>$y[$key],'data'=>$_stats_big_arr['analytics']];
			}
		}
	}
	
	json(1,1,$res);
}

if(!logged()) json(true,2,NULL,NULL,array('url'=>urlPanel,'js'=>'redirect'));


if(i('action') && $_POST['action']=='delete_all'){
	$module=e('module');
	$resp=db($module);
	if($resp!=1){
		for($i=0;$i<count($resp);$i++){
			$_POST['id']=$resp[$i]['id'];
			if(!delete($module,true))json(false,71);
			}
	}
	j();
	
}

elseif(i('del')){
	delete(e('del'),true);
	j();
}

elseif(i('canvas')){
//	dpd();
	if(!file_exists(target_dir.$_POST['filename']))json(false);
	if($_POST['canvas_field']==NULL || $_POST['filename']==NULL)json(false,4);
	
	$x=explode('.',$_POST['filename']);
	
	$img = str_replace('data:image/'.str_replace('jpg','jpeg',$x[1]).';base64,','', $_POST['canvas_field']);
//	dd($img);
	$img = str_replace(' ','+',$img);
	$data = base64_decode($img);
	
	if(!file_exists(target_dir.'original_'.$_POST['filename'])){
		if(!copy(target_dir.$_POST['filename'],target_dir.'original_'.$_POST['filename']))json(false);
		}
//	16669914071447831770
	foreach (glob(target_dir."*".$x[0]."*") as $filename) {
//		echo $filename;
		if(strpos($filename,'original_'))continue;
    	trash($filename);
	}
	$res = file_put_contents(target_dir.$_POST['filename'], $data);
	if(!$res)json(false);
	json(true,2);
}


elseif(i('uploadFast')){
	if($_FILES['file']['name'][0]==NULL)json(false,4);
	else {
		$module='uploader_1585790561';
		$file=escape(upload_file('single','file',$settings['file'],target_dir,'uploader_1585790561',false));
		json(true,1,'<div class="prebread_resp">
		<div class="prebread_item_row_sec">HTML</div>
		<div class="prebread_item_row copier po" onclick="c(\''.$file.'\');">'.$file.'</div>
		<div class="prebread_item_row copier po" onclick="c(\'/uploads/'.$file.'\');">/uploads/'.$file.'</div>
		<div class="prebread_item_row copier po" onclick="c(\''.u.$file.'\');">'.u.$file.'</div>
	</div>');
	}
	json(false);
}

elseif(i('qr')){
	$arr=[
		'cht'=>'qr',
		'chld'=>'H|0',
		'chco'=>str_replace('#','',$_POST['color']),
		'choe'=>'UTF-8',
		'chs'=>$_POST['dimension'].'x'.$_POST['dimension'],
		'chl'=>$_POST['value']];
		
		if($_POST['hash_origin']!=''){
		$_POST['hash']=hash_hmac('sha256',$_POST['hash_origin'],secret_key);
			$arr['chl'].='?hash='.$_POST['hash'];
			$_POST['value'].='?hash='.$_POST['hash'];
		}
	
	$fields=http_build_query($arr);
	$link='http://chart.apis.google.com/chart?'.$fields;
	$_POST['photo']=fileFromLink($link);
	co('codes_8311');
	$l=r('codes_8311');

	json(true,1,'<div class="prebread_resp">
		<div class="prebread_item_row_sec">HTML</div>
		<div class="prebread_item_row copier po" onclick="copy(this);">'.$_POST['photo'].'</div>

		<a target="_blank" class="prebread_item_row copier po" href="'.u.$_POST['photo'].'"><img src="'.u.$_POST['photo'].'"/></div>
	</div>');

	json(false);
}

elseif(i('menu_item_get')){
	jx(array('js'=>'menu_item_get_callback','data'=>o('menu_items_1564508835',e('menu_item_get'))[0]));
}



else if(i('action') && $_POST['action']=='export_csv'){
	$module=e('module');
	$where=NULL;
	
	if(i('ids') && $_POST['ids']!=NULL)
		$where="WHERE id IN (".e('ids').")";
	$resp=db($module,$where);
	
	$res=array();
	if($resp!=1){
		$fields=moduleFields(array('module_prefix'=>$module,'module_id'=>mid($module)))[3];
		array_unshift($fields,array('field_name'=>'id','label'=>'ID<>رقم المعرّف','type'=>'number'));
		foreach($resp as $r){
				$res[]=fieldsProcess($r,$fields,$module);
		}
		
		$field_names=array();
		foreach($fields as $f){
			$field_names[]=l($f['label']);
		}
	}

	
	jx(array('js'=>'exported','link'=>urlPanel.'exported/'.csv($res,mn($module).' '.cleanDate($date_created),$field_names)));
	
}


else if(i('action') && $_POST['action']=='mass_change'){
//	dp();
	// dd();
	
	if(i('ids') && $_POST['ids']!=NULL)
		$where="WHERE id IN (".e('ids').")";
	else json(false,4);
	$module=e('affected_module');
	$resp=db($module,$where);
	$tmp=$_POST;
	foreach($resp as $r){
//		$_POST=NULL;
		$_POST=[$tmp['mass_field']=>$tmp['mass_value']];
		co($module,$r['id']);
//		dp();
		r($module,'edit');
	}
	j();
//	json();
}
	
else if(i('action') && $_POST['action']=='export_csv_as_db'){
	$module=e('module');
	if(i('ids') && $_POST['ids']!=NULL)
		$where="WHERE id IN (".e('ids').")";
	$resp=db($module,$where);
	
	$res=array();
	if($resp!=1){
		$fields=moduleFields(array('module_prefix'=>$module,'module_id'=>mid($module)))[3];
		array_unshift($fields,array('field_name'=>'id','label'=>'ID<>رقم المعرّف','type'=>'number'));
		foreach($resp as $r){
				$res[]=fieldsProcess($r,$fields,$module,false,true);
		}
		
		$field_names=array();
		foreach($fields as $f){
			$field_names[]=$f['label'];
		}
	}

	
	jx(array('js'=>'exported','link'=>urlPanel.'exported/'.csv($res,mn($module).' '.cleanDate($date_created),$field_names)));
	
}



else if(i('action') && $_POST['action']=='export_xls'){
	$module=e('module');
	if(i('ids') && $_POST['ids']!=NULL)
		$where="WHERE id IN (".e('ids').")";
	$resp=db($module,$where);
	
	$res=array();
	if($resp!=1){
		$fields=moduleFields(array('module_prefix'=>$module,'module_id'=>mid($module)))[3];
		array_unshift($fields,array('field_name'=>'id','label'=>'ID<>رقم المعرّف','type'=>'number'));
		foreach($resp as $r){
			
				$res[]=fieldsProcess($r,$fields,$module,true);
		}
		
		$field_names=array();
		foreach($fields as $f){
			$field_names[]=l($f['label']);
		}
	}

	jx(array('js'=>'exported','link'=>urlPanel.'exported/'.xls($res,mn($module).' '.cleanDate($date_created).'_'.rand(),$field_names)));
	
}




else if(isset($_POST['pexel'])){
	$_m='files_1577206823';
	
	$resp=docurl($_POST['link'],NULL,false,true,false,array('Authorization:563492ad6f91700001000001533312341bfb45b7b32ae9df0e3f3e6d'));
	
	if($resp==NULL)json(false,97);
		
	if($_POST['file_type']=='photos'){
		for($i=0;$i<count($resp['photos']);$i++){
			$tmp=db($_m,"WHERE reference='".escape($resp['photos'][$i]['id'])."'",NULL,'LIMIT 1');
			if($tmp!=1){
				$resp['photos'][$i]['in_server']=true;
				$resp['photos'][$i]['server_file_info']=array(
					'url'=>u.$tmp[0]['full_name'],
					'desca'=>$tmp[0]['caption'],
					'filename'=>$tmp[0]['full_name'],
					'thumbnail_url'=>u.img($tmp[0]['full_name'],200,100),
					'originalFileName'=>$tmp[0]['original_name'],
					'name'=>$tmp[0]['original_name']
				);
			}
			else $resp['photos'][$i]['in_server']=false;
		}
	}else{
		for($i=0;$i<count($resp['videos']);$i++){
			$tmp=db($_m,"WHERE reference='".escape($resp['videos'][$i]['id'])."'",NULL,'LIMIT 1');
			if($tmp!=1){
				$resp['videos'][$i]['in_server']=true;
				$resp['videos'][$i]['server_file_info']=array(
					'url'=>u.$tmp[0]['full_name'],
					'desca'=>$tmp[0]['caption'],
					'filename'=>$tmp[0]['full_name'],
					'thumbnail_url'=>pres.'imgs/mp4.png',
					'originalFileName'=>$tmp[0]['original_name'],
					'name'=>$tmp[0]['original_name']
				);
			}
			else $resp['videos'][$i]['in_server']=false;
		}
	}
	
	
	json(true,2,$resp,NULL,array('js'=>'pexel_process'));
}

else if(isset($_POST['download_pexel'])){

	global $conn,$settings,$date_created,$admin_add_id;
	$_m='files_1577206823';
	
	$tmp=$_POST;
//	dp();
	$pexel_item=json_decode($_POST['pexel_item'],true);
	
	$content=download_content($tmp['file_type']=='photos'?$pexel_item['src']['large2x']:$pexel_item['video_files'][3]['link']);
	if($content===false)json(false,96);
	
	$x=explode('/',$pexel_item['url']);
	
	$originalName=$tmp['file_type']=='photos'?end(explode('/',$pexel_item['src']['original'])):$x[count($x)-2];
	$extension=$tmp['file_type']=='photos'?strtolower(end(explode('.',$originalName))):'mp4';
	$fileName=time().rand();
	$target_file=$fileName.'.'.$extension;
	file_put_contents(target_dir.$target_file,$content);
	
	if($tmp['file_type']=='photos')
		$picInfo=picInfo($target_file);

	
	
	
	$_POST=array();
	$_POST['full_name']=$target_file;
	$_POST['name']=$fileName;
	$_POST['original_name']=$x[count($x)-2].'.'.$extension;
	$_POST['extension']=$extension;
	$_POST['width']=$tmp['file_type']=='photos'?$picInfo['width']:$pexel_item['width'];
	$_POST['height']=$tmp['file_type']=='photos'?$picInfo['height']:$pexel_item['height'];
	$_POST['quality']=100;
	$_POST['size']=mb(filesize(target_dir.$target_file));
	$_POST['source_name']='Pexels';
	$_POST['source_link']=$pexel_item['url'];
	$_POST['reference']=$pexel_item['id'];
	$_POST['average_color']=$tmp['file_type']=='photos'?$pexel_item['avg_color']:'';
	$_POST['credit']=$tmp['file_type']=='photos'?$pexel_item['photographer']:$pexel_item['user']['name'];
	$_POST['credit_link']=$tmp['file_type']=='photos'?$pexel_item['photographer_url']:$pexel_item['user']['url'];
	$_POST['caption']=$tmp['file_type']=='photos'?$pexel_item['alt']:'';
	$_POST['type']=$tmp['file_type']=='photos'?'photo':'file';
	$_POST['sub_type']=$tmp['file_type']=='photos'?'':'video';
	$_POST['uploader_user_id']=isset($_SESSION['user_id'])?$_SESSION['user_id']:0;
	$_POST['uploader_module_prefix']=isset($_SESSION['module_id'])?$_SESSION['module_id']:0;
	co($_m);
	
	$t=db($_m,"WHERE id='".r($_m)."'",NULL,'LIMIT 1');
	
	$arr=array(
				'url'=>u.$t[0]['full_name'],
				'desca'=>$t[0]['caption'],
				'filename'=>$t[0]['full_name'],
				'thumbnail_url'=>$tmp['file_type']=='photos'?u.img($t[0]['full_name'],200,100):pres.'imgs/mp4.png',
				'originalFileName'=>$t[0]['original_name'],
				'name'=>$t[0]['original_name'],
				'reference'=>$t[0]['reference']
			);
	
	json(true,2,$arr,NULL,array('js'=>'file_from_link_callback'));
}


elseif(i('field_checker')){
	$field=db('module_fields',"WHERE field_name='".e('field')."' AND module_id='".mid($_POST['module'])."'");
	if($field==1)json(false);
	
	$field=$field[0];
	$value=e('value');
	if($field['is_unique']){
		$tmp=db(e('module'),"WHERE ".$field['field_name']."='$value'",NULL,'LIMIT 1');
		if($tmp!=1 && $tmp[0]['id']!=$_POST['id'])json(false);
	}
	
	if($field['field_name']=='slug'){
		if(preg_match('/[\p{Arabic}\p{Hebrew}]/u',$value)
		  || preg_match('~[^-\w]+~',$value)
		  )json(false);
	}

	
	json();
}


else if(isset($_POST['slugify'])){
//$a=slugify(l($settings['site_short_name'],'en')==''?l($settings['site_short_name'],'en'):l($settings['site_name'],'en')).'-';
	$slug=slugify(l(e('text'),'en'));
	$tmp=db(e('module'),"WHERE ".e('to_class')."='$slug'");
	if($tmp==1)json(true,1,$slug);
	else json(true,1,$slug); //'-'.rand(1,100)
	json(false);
}



else if(isset($_POST['seen_notification'])){
	mysqli_query($conn,"UPDATE web_notifications_1644647708 SET seen=1 WHERE id='".e('id')."' AND user='".$_SESSION['user_id']."' AND user_module='".$_SESSION['module_id']."'  AND seen=0 LIMIT 1");
	
	jx(array('js'=>'mark_seen_notification','id'=>$_POST['id']));
	
}

else if(isset($_POST['checker'])){
	$engine_update=NULL;
	$sub_build_details=NULL;
	$notifications=NULL;
//json(false);
	if($_POST['check_new_version']){
		$resp=docurl('https://legioncms.com/api/1.0/',array('api'=>'sub_build','main_version'=>main_version,'sub_version'=>sub_version,'website_link'=>cms_url),true);

		if(isset($resp['data']['this_website']) && ($resp['data']['this_website']==NULL || $resp['data']['this_website']['id']<$resp['data']['last_push']['id']) && super())
			$engine_update=array('link'=>urlPanel.'?module=settings&action=updater&lang='.curr());

		if($_POST['got_sub_build']=='false'){
			$tmp=(!isset($resp['data']['this_website']['id']) || $resp['data']['this_website']['id']==NULL?0:$resp['data']['this_website']['id']);
			$sub_build_details=array(
				'this_sub_build'=>$tmp,
				'this_sub_build_with_dot'=>'.'.$tmp
			);
		}
	}
	
	$tmp=db('web_notifications_1644647708',"WHERE user_module='".$_SESSION['module_id']."' AND user='".$_SESSION['user_id']."' AND id>'".e('last_notification_id')."' AND deleted=0","ORDER BY id ASC");
	if($tmp!=1 && $tmp!=0){
		$notifications=array();
		for($i=0;$i<count($tmp);$i++){
			$notifications[]=processNotification($tmp[$i]);
		}
	}
	jx(array('js'=>'checked','engine_update'=>$engine_update,'sub_build_details'=>$sub_build_details,'notifications'=>$notifications));
}


else if(isset($_POST['updater'])){
	
	if(!isset($_POST['updater_type']) || !isset($_POST['google_auth_code']) || $_POST['google_auth_code']=='')json(false,4);
	
	if($_POST['updater_type']=='pull_updater'){
			$res=docurl('https://legioncms.com/api/1.0/',array('api'=>'puller','google_auth_code'=>$_POST['google_auth_code'],'main_version'=>main_version,'sub_version'=>sub_version,'website_link'=>cms_url),true);
		
			$_POST['internal']=true;
			json($res['response'],$res['code']);
		
	
			$pre=cms_dir.'preupdater.php';
			if(!copy($res['data']['pre_link'],$pre))json(false,6);
			include $pre;
		
		json();
	}
	
	
	
	$res=docurl('https://legioncms.com/api/1.0/',array('api'=>'prepush','google_auth_code'=>$_POST['google_auth_code'],'main_version'=>main_version,'sub_version'=>sub_version,'website_link'=>cms_url),true);

	$pre=cms_dir.'prepusher.php';
	
	if(!copy($res['data']['pre_link'],$pre))json(false,6);
	
	include $pre;
	
	j();
}


else if(i('action') && $_POST['action']=='sort_entries'){
	$_m=e('module');
	if(isset($_POST['clear_sort_all'])){
		if(!mysqli_query($conn,"UPDATE $_m SET order_number=1000"))json(false);
	}
	
	if($_POST['id']!=NULL){
		for($i=0;$i<count($_POST['id']);$i++){
			if(!mysqli_query($conn,"UPDATE $_m SET order_number=$i WHERE id='".escape($_POST['id'][$i])."' LIMIT 1"))json(false);
		}
	}
	j('refresh');
}

else if(isset($_POST['module']) && $_POST['module']=='uploader'){
	require panel_dir.'uploader.php';
	json(false);
}


else if(i('action') && $_POST['action']=='floodTrash'){
		$module_prefix=escape($_POST['module']);
	
	if($module_prefix=='files_1577206823'){
		$resp=db($module_prefix,"WHERE deleted=1");
		for($i=0;$i<count($resp);$i++){
			$target_dir=$resp[$i]['protected_file']=='1'?_protected:target_dir;
			foreach (glob($target_dir."*".$resp[$i]['name'].'*') as $filename) {
				trash($filename);
			}
		}
	}
		if(mysqli_query($conn,"DELETE FROM $module_prefix WHERE deleted=1"))json(true,2,NULL,NULL,['js'=>'redirect',"url"=>returnUrl()]);
		json(false);
	}


else if(isset($_POST['module']) && $_POST['module']=='active'){
        $id=id();
		$module_prefix=escape($_POST['module_prefix']);
		$booleanField=escape($_POST['booleanField']);
		if(!mysqli_query($conn,"UPDATE $module_prefix SET $booleanField=1-$booleanField WHERE id='$id' LIMIT 1"))json(false);
		json(true,43,NULL,NULL,['js'=>'switchActive','id'=>$id,'boolField'=>$booleanField]);
		
	}



else if(i('type') && $_POST['type']=='menu_style'){
	require core_dir.'modules/menu_style.php';
	json(false); 
	}

else if(i('darkMode')){
	$tmp=$_POST;
	$_POST=[];
	co('admins',$_SESSION['user_id']);
	if(filter_var($tmp['darkMode'], FILTER_VALIDATE_BOOLEAN))$_POST['dark_mode']=1;
	else unset($_POST['dark_mode']);
	r('admins','edit');
	json(); 
	}

else if(i('action') && $_POST['action']=='unfoldInstalled' && super()){
	if(mysqli_query($conn,"UPDATE settings SET unfoldInstalled=1-unfoldInstalled WHERE id=1 LIMIT 1"))json(true,65);
	json(false);
	}


else if(i('module') && $_POST['module']=='empty_table' && super()){
	$affected_module=i('affected_module')?e('affected_module'):e('id');
	mail('omar@provision.ps','Empty Table - '.$settings['site_short_name'],"
Table: $affected_module
User: ".$userInfoArr['username']."
Date: $date_created
URL:".url."
"
		);
	mysqli_query($conn,"TRUNCATE TABLE $affected_module");
	json(true,27);
	}

elseif(i('module') && $_POST['module']=='toggle_restrict' && super()){
	$tableName=escape($_POST['id']);
	mysqli_query($conn,"UPDATE modules SET restricted=1-restricted WHERE module_prefix='$tableName'");
	json(true,2,NULL,NULL,['js'=>'refresh']);
	}

elseif(i('module') && $_POST['module']=='toggle_external_access' && super()){
	$tableName=escape($_POST['id']);
	mysqli_query($conn,"UPDATE modules SET external_access=1-external_access WHERE module_prefix='$tableName'");
	json(true,2,NULL,NULL,['js'=>'refresh']);
	}





elseif(i('action') && $_POST['action']=='get_menu_items'){
	$module_prefix=escape($_POST['module_prefix']);
	$resp=db('module_settings',"WHERE module_prefix='$module_prefix' AND menu_field!=''",NULL,'LIMIT 1','menu_field');
	if($resp==0 || $resp==1)json(false);
	$menu_field=$resp[0]['menu_field'];
	$resp=db($module_prefix,NULL,NULL,NULL,$menu_field.',id');
	if($resp!=1)
		for($i=0;$i<count($resp);$i++){$resp[$i][$menu_field]=l($resp[$i][$menu_field]);}
	json(true,1,$resp,NULL,['js'=>'itemRefresher']);
}


elseif(i('action') && $_POST['action']=='sort_menu_items'){
	for($i=0;$i<count($_POST['sort_menu_item']);$i++){
		$id=escape($_POST['sort_menu_item'][$i]);
		mysqli_query($conn,"UPDATE menu_items_1564508835 SET order_num='$i',sub_of='0' WHERE id='$id' LIMIT 1");
	}
	if(isset($_POST['sorting_item_id']) && is_array($_POST['sorting_item_id'])){
		for($i=0;$i<count($_POST['sorting_item_id']);$i++){
			$_POST['sorting_item_id'][$i]=escape($_POST['sorting_item_id'][$i]);
			$exploded=explode('#',$_POST['sorting_item_id'][$i]);
			mysqli_query($conn,"UPDATE menu_items_1564508835 SET sub_of='".$exploded[1]."' WHERE id='".$exploded[0]."' LIMIT 1");
		}
	}
	json(true,2);
}


elseif(i('action') && $_POST['action']=='delete_menu_item'){
	$_POST['internal']=true;
	delete('menu_items_1564508835');
	json(true,2,NULL,NULL,['js'=>'refresh']);
}


//check if empty field is not empty or set
if (!isset($_POST['e']) || $_POST['e'] != "") json(false,8);
//validate type


if (!isset($_POST['module']) || $_POST['module']==NULL || !i('action') || $_POST['action']==NULL)json(false,8);
$module=escape($_POST['module']);
$action=escape($_POST['action']);


if($action=='restore'){
	if(privilege($module,'delete')){
	if(mysqli_query($conn,"UPDATE $module SET deleted=0 WHERE id='".id()."' LIMIT 1"))json(true,1,NULL,NULL,array('js'=>'refresh'));
		}
	json(false);
}

else if($action=='multi_restore'){
	if(privilege($module,'delete')){
		$_POST['ids']=explode(',',$_POST['ids']);
	for($i=0;$i<count($_POST['ids']);$i++){
		if(!mysqli_query($conn,"UPDATE $module SET deleted=0 WHERE id='".escape($_POST['ids'][$i])."' LIMIT 1"))json(false,72);
		}
	
	$_POST['force_refresh']=true;
	json();

		}
	json(false);
}



else if($action=='multi_delete_trash'){
	if(privilege($module,'edit')){
		$_POST['ids']=explode(',',$_POST['ids']);
	for($i=0;$i<count($_POST['ids']);$i++){
		if(!mysqli_query($conn,"DELETE FROM $module WHERE id='".escape($_POST['ids'][$i])."' LIMIT 1"))json(false,72);
		}
	
	$_POST['force_refresh']=true;
	json();

		}
	json(false);
}


else if($action=='add_in_menu'){
	$_POST['module_field']=detail('module_settings','menu_field','module_prefix',e('module_prefix'));
    if($_POST['module_field']==NULL)$_POST['module_field']='NA';
	$action=$_POST['action']='add';
	$_POST['force_refresh']=true;
}


else if($action=='edit_in_menu'){
	$_POST['module_field']=detail('module_settings','menu_field','module_prefix',e('module_prefix'));
    if($_POST['module_field']==NULL)$_POST['module_field']='NA';
	$action=$_POST['action']='edit';
	$_POST['force_refresh']=true;
}




else if($action=='insert_test' && privilege($module,'add')){
	
	$module_id=detail('modules','id','module_prefix',$module);
	
	$module_fields=db('module_fields',"WHERE module_id='$module_id'");
	
	for($i=0;$i<(int)$_POST['count'];$i++){
		foreach($module_fields as $field){
			$_POST[$field['field_name']]=dummer($field);
		}

		completer($module);
		r($module);
	}
	
	$_POST['force_refresh']=true;
	json();
}

else if($action=='multi_delete'){#delete function tests privilege, dont worry 
	$_POST['ids']=explode(',',$_POST['ids']);
	for($i=0;$i<count($_POST['ids']);$i++){
		$_POST['id']=$_POST['ids'][$i];
		if(!delete($module,true))json(false,71);
		}
	
	$_POST['force_refresh']=true;
	json();
}


else if($action=='multi_copy' && privilege($module,'add')){
	$module_id=detail('modules','id','module_prefix',$module);
	$ids=explode(',',$_POST['ids']);
	$last_id=intval(db($module,"WHERE id!=''",NULL,'LIMIT 1','id')[0]['id']);
	

	
	for($i=0;$i<count($ids);$i++){
		$last_id++;
	$f=NULL;
	$resp=db($module,"WHERE id='".$ids[$i]."'",NULL,'LIMIT 1')[0];
		if($resp==NULL)json(false,98);
	$keys= array_keys($resp);
	for($j=0;$j<count($keys);$j++){
		if($keys[$j]=='id')$resp[$keys[$j]]=$last_id;
		$f.="'".escape($resp[$keys[$j]])."',";
	}
		$f=rtrim($f,',');
		if(!mysqli_query($conn,"INSERT INTO $module VALUES ($f)"))json(false,3);
		}
	
	$_POST['force_refresh']=true;
	json();
}




else if($action=='copy' && privilege($module,'add')){
	$module_id=detail('modules','id','module_prefix',$module);
	$last_id=intval(db($module,"WHERE id!=''",NULL,'LIMIT 1','id')[0]['id']);
	
	$last_id++;
	$f=NULL;
	$resp=db($module,"WHERE id='".e('id')."'",NULL,'LIMIT 1')[0];
	$keys=array_keys($resp);
	for($j=0;$j<count($keys);$j++){
		if($keys[$j]=='id')$resp[$keys[$j]]=$last_id;
		$f.="'".escape($resp[$keys[$j]])."',";
	}
		$f=rtrim($f,',');
		if(!mysqli_query($conn,"INSERT INTO $module VALUES ($f)"))json(false,3);
	
	$_POST['force_refresh']=true;
	json();
}





if(privilege($module,$action)){
	if($action=='delete'){delete($module);}
	else if($action=='list'){
		require_once core_dir.'modules/listSub.php';
		$m=db('module_settings',"WHERE module_prefix='$module'",NULL,"LIMIT 1");
		if($m==0 || $m==1)die('couldnt get module settings, contact ProVision');
		}
	
	else{
		include_once modules_dir.$module.'/models/'.$action.'.php';
	}
}
json(false,3);