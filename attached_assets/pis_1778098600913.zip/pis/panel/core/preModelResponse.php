<?php
if(isset($module) && $module=='admins'){
	if(isset($_POST['roles'])){
		if($action=='edit'){
			$which_id=$id;
			if(($action=='edit' && privilege('admins','edit')) && (super() || $_SESSION['user_id']!=$id)){
				mysqli_query($conn,"DELETE FROM privileges_1565709771 WHERE user_id='$which_id'");
			}
		}else $which_id=$prime_last_id;

		if(isset($_POST['roles'])){
			if(($action=='add' && privilege('admins','add')) || (($action=='edit' && privilege('admins','edit')) && (super() || $_SESSION['user_id']!=$id))){
				for($i=0;$i<count($_POST['roles']);$i++){
					$role=escape($_POST['roles'][$i]);
					$role=explode(',',$role);
					 if(!privilege($role[0],$role[1]))continue;
					mysqli_query($conn,"INSERT INTO privileges_1565709771 (module_name, type_name, user_id) VALUES ('".$role[0]."','".$role[1]."','$which_id')");

				}
			}
		}

		require mailer;
	}
}

else if(isset($module) && $module=='fonts_1582219344'){
	fonts();
}

else if(isset($module) && $module=='bulk_push_notification_1633289547' && $action=='add'){
	psn($title,$message);
}


else if(isset($module) && $module=='bulk_sms_1652425418' && $action=='add'){
	$field=db('module_fields',"WHERE id='".e('mobile_field')."'");
	if($field!=1 && $field!=0){
		$mobiles=db(one('modules',e('module_prefix'))[0]['module_prefix'],"WHERE deleted=0 AND ".$field[0]['field_name']."!=0",NULL,NULL,'mobile');
		if($mobiles!=1 && $mobiles!=0){
			$msg=l($_POST['message']);
			foreach($mobiles as $mobile){
				smss($mobile['mobile'],$msg);
			}
		}
	}
	
}

else if(isset($module) && $module=='color_palette_1645099749'){
	colors();
}

else if(isset($module) && $module=='link_handler_1566934564' && super()){
	$_POST['internal']=true;
    require modules_dir.'settings/models/reset_htaccess.php';
	autoMetaResetter();
}

elseif(i('updateListRow')){
	require custom_dir.'custom_list.php';
	require core_dir.'configList.php';
	if($_module!=NULL){
		$m=db('module_settings',"WHERE module_prefix='$_module'",NULL,"LIMIT 1");
		if($m!=0 || $m!=1){
			$m=$m[0];
			$m['info']=db('modules',"WHERE module_prefix='$_module'",NULL,'LIMIT 1')[0];
			$m['module_id']=$m['info']['id'];
		}

		#1 fields from module_fields
		list($m,$main_field,$f)=moduleFields($m);
		//d($m);

		#2 permission
		$canDelete=privilege($m['module_prefix'],'delete');
		$canEdit=privilege($m['module_prefix'],'edit');
		$canView=privilege($m['module_prefix'],'view');
		$canView=true;

		$tr='<tr id="tr_'.$id.'">';
		
		for($j=0;$j<count($main_field);$j++){
			
			$tr.='<td>'.td($main_field[$j],o($_module,$id)[0],$m,$canDelete,$canEdit,$f,$canView).'</td>';
			
		}
//		dd('hi');
		$tr.='</tr>';
		
		json(true,1,NULL,NULL,['js'=>'updateListRow','id'=>$id,'tr'=>$tr]);
	}
}

##focus
include panel_dir.'notify.php';