<?php 
if(!isset($embed_app)){
	$_GET['mobile']=true;
	require 'header.php';
	}
$_app=o('apps_1552305519',1);
if($_app==1){
	echo '<div id="app_download_error">'.l('Contact ProVision to fix the app configuration<>تواصل مع بروفجن لإصلاح اعدادات التطبيق').'</div>';
}else{
	$_app=$_app[0];
	if(!isset($embed_app)){
?>
<div id="app_download_wrap">
	
	<?php }?>
	<div class="par">
		<div class="ch">
			<div id="app_download_cont">
				<?php if(!isset($embed_app)){?>
				<a href="<?= url.'index.php?lang='.curr()?>" title="<?= l($settings['site_short_name'])?>" class="app_download_logo mid">
					<?= pic($settings['logo'],600,100,l($settings['site_short_name']),true,'downa_logo_pic')?>
				</a>
				<?php }?>

				<div class="app_download_title"><?=isset($custom_action_txt)?$custom_action_txt:l('Get '.l($settings['site_short_name']).' App<>
				نزّل تطبيق '.l($settings['site_short_name']))?></div>

				<?php if((!g('device') || (g('device') && $_GET['device']=='all') || (g('device') && $_GET['device']=='ios')) && $_app['apple_store_id']!='' && $_app['ios_active']){?>
					<a href="https://apps.apple.com/us/app/provision/id<?=$_app['apple_store_id']?>?l=<?=curr()?>" target="_blank" title="<?=l('Download '.l($settings['site_short_name']).' on iOS<> تنزيل تطبيق '.l($settings['site_short_name']).' على ابل')?>" class="app_download_btn">
						<?php pic($_app['ios_download_image']==''?'download_ios.png':$_app['ios_download_image'],400,100,l($settings['site_short_name']),true,NULL,'app_download_btn_img')?>
					</a>
				<?php }?>

				<?php if((!g('device') || (g('device') && $_GET['device']=='all') || (g('device') && $_GET['device']=='android')) && $_app['android_store_id']!='' && $_app['android_active']){?>
				<a href="https://play.google.com/store/apps/details?id=<?=$_app['android_store_id']?>" target="_blank" title="<?=l('Download '.l($settings['site_short_name']).' on Android<> تنزيل تطبيق '.l($settings['site_short_name']).' على الاندرويد')?>" class="app_download_btn">
					<?php pic($_app['ios_download_image']==''?'download_android.png':$_app['android_download_image'],400,100,l($settings['site_short_name']),true,NULL,'app_download_btn_img')?>
				</a>
				<?php }?>
				<?php if(!isset($embed_app)){include 'legion_share.php';}?>
			</div>
		</div>	
	</div>
	<?php if(!isset($embed_app)){?>
</div>
<?php }?>
<?php 
	
	 }


?>


<style>
	<?php if(!isset($embed_app)){?>
	mh{display: none;}
	body{font-family: verdana}
	<?php }else{?>

	
	<?php }?>
	
</style>

<?php 

if(!isset($embed_app)){
	require 'footer.php';
}