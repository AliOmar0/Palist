<?php require 'header.php';?>


<div id="event" class="w1200">
<div id="adv_title"><?=l($post['title'])?></div>
	<div class="event_photo in"><?php pic(l($post['photo']))?></div>	
 <div class="events_and_conferences_events_description mce in">
	<?= l($post['content'])?>
	</div>	   
</div>




<?php include 'legion_share.php'?>
<?php require 'footer.php';?>