//'use strict';

var cacheVersion = 3;
var currentCache = {
  offline: 'offline-cache' + cacheVersion
};

const offlineUrl = 'offline.html';


this.addEventListener('install', event => {
  event.waitUntil(
    caches.open(currentCache.offline).then(function(cache) {
      return cache.addAll([
		  '/',
          offlineUrl,
		  'uploads/nointernet.png',
		  'uploads/default_fav.png',
		  'uploads/default_logo.png'
	  ]);
    })
  );
});




this.addEventListener('fetch', event => {
		    if (event.request.url.indexOf('panel') !== -1) { return; }
		    if (event.request.url.indexOf('mp4') !== -1) { return; }
  // request.mode = navigate isn't supported in all browsers
  // so include a check for Accept: text/html header.
	
  if (event.request.mode === 'navigate' || (event.request.method === 'GET' && event.request.headers.get('accept').includes('text/html'))) {
        event.respondWith(
          fetch(event.request.url).catch(error => {
              // Return the offline page
              return caches.match(offlineUrl);
          })
    );
  }
  else{
        // Respond with everything else if we can
        event.respondWith(caches.match(event.request)
                        .then(function (response) {
                        return response || fetch(event.request);
                    })
            );
      }
});