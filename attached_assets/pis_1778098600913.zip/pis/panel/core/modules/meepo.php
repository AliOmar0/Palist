<link rel="stylesheet" type="text/css" href="<?= pres;?>css/meepo.css<?php clearCache();?>"/>
<script src="<?= pres?>js/meepo.js<?php clearCache();?>"></script>


<link rel="stylesheet" type="text/css" href="<?= pres;?>css/colorpicker.css<?php clearCache();?>"/>
<script src="<?= pres?>js/colorpicker.min.js<?php clearCache();?>"></script>


<link rel="stylesheet" type="text/css" href="<?= pres;?>css/gradX.css<?php clearCache();?>"/>
<script src="<?= pres?>js/gradX.js<?php clearCache();?>"></script>




<form id="meepo_1646265283" autocomplete="off" action="" onsubmit="meepoSave();return submitter(this,'<?=urlPanel?>');" method="post" enctype="multipart/form-data">
	<input type="hidden" value="" name="e">
	<input type="hidden" name="module" value="meepo_1646265283"> 
	<input type="hidden" name="action" value="edit"> 
	<input type="hidden" name="id" value="1"> 
	<textarea name="html" class="hidden"></textarea>
	<input type="hidden" name="title" value="test"/>
	<input type="submit" class="btn" value="<?=l('Save<>حفظ')?>"/>
</form>

<?php $resp=detail('meepo_1646265283','html','id',1)?>

	  
<div id="meepo">
        <div id="meLabelEditTools" class="hidden">
            <label>Text</label>
            <input id="meLabelTextEdit" type="text"/>
            
            <label>Font Size</label>
            <input id="meLabelTextEditFontSize" type="text"/>
            
            <label>Color</label>
            <input id="meLabelTextEditColor" type="color"/>
            
             <label>Text Align</label>
            <select class="noSelect2" id="meLabelTextEditAlign">
                <option value="meLeft">Left</option>
                <option value="meCenter">Center</option>
                <option value="meRight">Right</option>

            </select>
        </div>
        
        
        <div id="meFrame">
            <div id="meToolsWrap" class="noselect">
                <div id="meToolsCon">
                    
                <div id="meElementsSuggestions">
            
            <div class="meLabelSugg in move" draggable="true" data-mesampletoget="meRow" ondragstart="drag(event,this)">
                <i class="mid">horizontal_rule</i>
                <div class="meLabelSuggName mid">Row</div>
            </div>
                    
                    
            <div class="meLabelSugg in move" draggable="true" data-mesampletoget="meLabel" ondragstart="drag(event,this)">
                <i class="mid">label</i>
                <div class="meLabelSuggName mid">Label</div>
            </div>
            
            <div class="meLabelSugg in move" draggable="true" data-mesampletoget="mePhoto" ondragstart="drag(event,this)">
                <i class="mid">insert_photo</i>
                <div class="meLabelSuggName mid">Photo</div>
            </div>
            
             <div class="meLabelSugg in move" draggable="true" data-mesampletoget="meTextArea" ondragstart="drag(event,this)">
                <i class="mid">notes</i>
                <div class="meLabelSuggName mid">TextArea</div>
            </div>
            
        </div>
                
                
            </div>
           </div> 
           
            
	<div id="meepoBig">
            <div id="meBoard" ondrop="drop(event)" ondragover="allowDrop(event)"  ondragleave="leaveDrop(event)">
				<?=$resp?>
            </div>
		
        </div>
			
	</div>
        <div id="meRights">MEEPO - Blocks Builder - developed by ProVision for Legion CMS ©</div>
  
        
        
        <div id="meSamples" class="hidden">
			
             <div class="meColumn meElem in"></div>
            
			
			  <div class="meRow meElem">
              	<div class="meRowColumnsArea"></div>
              </div>
			

            <div class="meLabel meElem">
                <div class="meLabelText">Label</div>
            </div>
            
            <div class="mePhoto meElem">
                <img src="<?=u?>default_logo.png"/>
            </div>
            
             <div class="meTextArea meElem">
                <div class="meTextAreaContent">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et Malorum for use in a type specimen book.</div>
            </div>
            
        </div>
        
        
        
        
        
        <div id="meElemToolsSamples" class="hidden">
			
			
			<div class="meElemTool meElemTool_add_column in po" onClick="meAdd(this)">
                        <i class="mid">view_week</i>
                        <div class="mid">Add Column</div>
                    </div>
                    
                    <div class="meElemTool meElemTool_delete in po" onClick="meDelete(this)">
                        <i class="mid">delete_sweep</i>
                        <div class="mid">Delete</div>
                    </div>
			
			
			 <div class="meElemTool meElemTool_background in po" onClick="meColor(this)" data-me_css='background'>
                        <i class="mid">palette</i>
                        <div class="mid">Background Color</div>
                    </div>
			
			
			 <div class="meElemTool meElemTool_color in po" data-me_css='color' onClick="meColor(this)">
                        <i class="mid">format_color_text</i>
                        <div class="mid">Font Color</div>
                    </div>
			
			
			
			<div class="meElemTool meElemTool_photo in po" onClick="mePhotoBrowse(this)">
                        <i class="mid">image</i>
                        <div class="mid">Photo</div>
                    </div>
			
			
			
<!--
            <div class="meElemToolsWrap">
                <div class="meElemToolBox in" onClick="meDelete(this)">
                    Delete
                </div>
                <div class="meElemToolBox in" onClick="meEdit(this)">
                    Edit
                </div>
                
                <div class="meElemToolBox in" onClick="meUp(this)">
                    Up
                </div>
                
                <div class="meElemToolBox in" onClick="meDown(this)">
                    Down
                </div>
                
            </div>
-->
        
        </div>
	
	
	<div id="meOneElement" class="hidden">
	
		<div id="meColorOptions" class="chooser_wrap" style="display:none">
			<?php $_m='color_palette_1645099749';?>
			<!--<?php
			$resp=db($_m,NULL,NULL);
			if($resp==1) echo 'No Data';
			else { for($i=0;$i<count($resp);$i++){?>
			--><div class="color_palette_color in po" style="background: <?=$resp[$i]['color']?>" title="<?=l($resp[$i]['name'])?>">
				</div><!--
			<?php 
				}//for
			}//else
			unset($resp);?>
			--><div class="color_palette_color in po meGradientPicker" style="background: var(--modernG)" title="<?=l('Gradient')?>">
			</div>
		</div>

		
	</div>
        
  </div>


<style>

/*	.meAboveTools{display:unset}*/
</style>


  <div id="gradX" style="display:none"></div>