 <?php
//ProVision is the best


if(i('c_editProfile')){

	if(!logged(mid($_user)))j();
//	unset($_POST['active']);
	co($_user,$_SESSION['user_id']);
	$_POST['id']=$_SESSION['user_id'];
	unset($_POST['password']);
	r($_user,'edit');
	json(true,2);
}



elseif(i('j_editProfile')){
	// echo "edit";
// $fmi=4;
	// if(!logged(mid($_user)))j();
//	unset($_POST['active']);
// echo "po ".$_POST['id'];
	co($_join_request,$_POST['id']);
	// $_POST['id']=$_POST['id'];
	// unset($_POST['password']);
	if($_POST['submitted']==1 || $_POST['active']==1){
		// echo 'se '.$_SESSION['user_id'];
		$user=db($_user,"WHERE id='".$_SESSION['user_id']."'")[0];
			
		$username=$user['username'];
		// echo 'se '.$user['username'];
		require mailer;
	}
	r($_join_request,'edit');
	
	// json(true,124,NULL,NULL,array('js'=>'saved'));
	json(true,123,NULL,NULL);

}

elseif(i('new_request')){
	$fmi=10;
	if(!logged(mid($_user)))j();
	$_POST['internal']=true;
	$_POST['user']=$_SESSION['user_id'];
	$_POST['active']=0;
	$_POST['submitted']=1;
	// require modules_dir.$_join_request.'/models/add.php';
	r($_join_request,'add');
	$username=$_POST['user'];
	$email_address=$_POST['email_address'];
	require mailer;
	json(true,123,NULL,NULL,array('js'=>'successjoin'));
}

elseif(i('module') && $_POST['module']=='contact_form_8363' && $_POST['action']=='add' && isset($_POST['new_user'])){
    $_POST['internal']=true;
require modules_dir.'contact_form_8363/models/add.php';
require mailer;
json(true,1,NULL,NULL,array('js'=>"successConnected"));

}

elseif(i('module') && $_POST['module']=='join_us_8367' && $_POST['action']=='add' && isset($_POST['user'])){
	$_POST['internal']=true;
    require modules_dir.'join_us_8367/models/add.php';
    json(true,1,NULL,NULL,array('js'=>'successJoined'));
}

elseif(i('module') && $_POST['module']=="joining_request_form_8371" && $_POST['action']=='edit' && isset($_POST['id'])){
	$id=e('id');
	
 	$resp=db("joining_request_form_8371","WHERE id='$id' AND deleted='0'",NULL);
	// d($resp);
	//  d($_POST['active']);
	if(isset($_POST['active']) && $resp[0]['active']=='0'){
	// d('SHIREEN');
		$fmi=4;
		$useremail=$resp[0]['email_address'];
		// d($useremail);
		include mailer;
		
	}
	// die();
}
elseif(i('c_login')){
	$email=escape($_POST['email_address']);
	$resp=db($_user,"WHERE email_address='$email' AND deleted='0'",NULL,NULL);
// d($resp);
	if($resp==0)json(false,3);
	else if($resp==1)json(false,73);
	
	// else if($resp[0]['active']=='0')json(false,49);

	else if($resp[0]['active']=='0')json(false,49,NULL,NULL,array('js'=>"popError"));
	else if(!password_verify($_POST['password'], $resp[0]['password']))json(false,121);
//	$_POST['rememberme']=true;

	// elseif($resp[0]['active']=='1'){
	// 	$fmi=4;
	// 	$user=db('user_8403',"WHERE !deleted AND user=".$_SESSION['user_id'],NULL);
	// 	$active_email=$user[0]['email'];
	// 	require mailer;
	// }


	logUserIn($resp[0]['id'],mid($_user));
    json(true,1,NULL,NULL,array('url'=>urlp('dashboard'),'js'=>'redirect'));
	
}


elseif(i('c_signup')){
	$_POST['internal']=true;
	$_POST['active']=0;
	$username=$_POST['username'];
	$email=$_POST['email_address'];
	require modules_dir.$_user.'/models/add.php';
	require mailer;
	json(true,1,NULL,NULL,array('js'=>'successSignup'));
}


elseif(i('c_changePassword')){
	if(!logged(mid($_user)))j();
	
	$this_module=$_user;
			$user_id=$_SESSION['user_id'];
	      	$old=escape($_POST['old']);
			$new=escape($_POST['new']);
			$confirm=escape($_POST['confirm']);
			$resp=db($this_module,"WHERE id='$user_id' AND deleted='0'",NULL,"LIMIT 1",'password');
			if($resp==0)json(false,3);
			else if($resp==1)json(false,3);

			if(!password_verify($old, $resp[0]['password']))json(false,73);
			if($new!=$confirm)json(false,74);
			if($new==$old)json(false,75);
		checkPassword($new);
		
		$password=password_hash($new, PASSWORD_DEFAULT);
		
		if(!mysqli_query($conn,"UPDATE $this_module SET password='$password' WHERE id='$user_id' LIMIT 1"))json(false,3);

		
		if(!mysqli_query($conn,"DELETE FROM tokens WHERE user_id='$user_id' AND module_prefix='$this_module'"))json(false,3);
		
		
		json(true,2,NULL,NULL,array('js'=>'c_success'));
}
elseif(i('c_forgot')){
	$module='users_8400';
	$_POST['action']='edit';
	$resp=db('users_8400',"WHERE email_address='".e('email_address')."'");
	$website_name="PIS";
	if($resp!=1){
		$fmi=8;
		$unhashed_password='pis'.rand(11111311,9999999999);
		$hashed=password_hash($unhashed_password, PASSWORD_DEFAULT);
		$id=$resp[0]['id'];
		mysqli_query($conn,"UPDATE users_8400 SET password='$hashed' WHERE id=$id LIMIT 1");
		$email_address=l($resp[0]['email_address']);
		$full_name=$resp[0]['full_name'];
		
		require mailer;
		
		json(true,122,NULL,NULL,array('js'=>'c_forgot_func'));

		}else{
			json(false,81);
		}
}
//   -->
elseif(i('module') && $_POST['module']=="users_8400" && $_POST['action']=='edit' && isset($_POST['id'])){
    $id=e('id');
    
    $resp=db("users_8400","WHERE id='$id' AND deleted='0'",NULL);
    // d($resp);
    //  d($_POST['active']);
    if(isset($_POST['active']) && $resp[0]['active']=='0'){
    // d('SHIREEN');
        $fmi=9;
        $useremail=$resp[0]['email_address'];
        d($useremail);
        include mailer;
        
    }
    // die();
}