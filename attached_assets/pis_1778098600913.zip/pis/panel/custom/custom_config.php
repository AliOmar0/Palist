<?php
//ProVision is the best


// $_join='joining_request_form_8371';

$_user='users_8400';
$_join_request='joining_request_form_8371';

function goSign(){
	echo '<script>window.location.href = "https://intel.ps/pis/page/signin/'.get_curr_language().'";</script>';
}

function confirm_password_hash(){
    
}

