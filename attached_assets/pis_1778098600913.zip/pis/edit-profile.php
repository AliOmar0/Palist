

<?php

if(isLogged(mid($_user))){?>


	<?php
	
	 echo form($_user,'c_editProfile');
	$_GET['id']=$_SESSION['user_id'];
	$passOnce=true;
	v($_user,'edit',false);
	
//	 require modules_dir.$_usere.'/views/editNoForm.php';
	?>
<input type="submit" value="<?= l('Save<>حفظ')?>" class="btn edit_btn"/>
</form>
</div>
    
<script>
	$('.<?=$_user?>_password,.<?=$_user?>_confirm_password').hide();	
</script>

<?php
	$module=$_user;
	include 'legion_front_handler.php';
}else{
   goP();	
} 