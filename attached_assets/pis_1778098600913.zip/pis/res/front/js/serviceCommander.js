// Register the service worker
if ('serviceWorker' in navigator) {
	navigator.serviceWorker.register(url+'sw.js').then(function(registration) {
    // Registration was successful
    console.log('ProVision SW registration successful | scope: ', registration.scope);
}).catch(function(err) {
    // registration failed :(
    	console.log('ProVision SW registration failed: ', err);
    });
}