<?php if($settings['clear_cache']==1)header('Cache-Control: no-store, no-cache, must-revalidate')?>
<!doctype html>
<html dir="<?=direction()?>" lang="<?=curr()?>">
<?=rights?>

<head>
	<link href="<?=fres?>css/fonts.css<?php clearCache()?>" rel="preload stylesheet" as="style">
	<BASE href="<?=url; ?>">
	<meta charset="UTF-8"/>
	<link rel="alternate" hreflang="<?=curr()?>" href="<?=url.curr()?>"/>
    <link rel="canonical" href="<?=url.curr()?>"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes">
	
	<?php require 'legion_meta.php'?>
     
	<!--ProVision Legion Resources-->
	<?php require panel_dir.'sharedHeader.php'?>

	<link rel="stylesheet" type="text/css" href="<?=fres?>css/provision.css<?php clearCache()?>" media="all"/>
    <link rel="stylesheet" href="<?=pres?>css/mce.css<?php clearCache()?>" media="none" onload="this.media='all';"/>
	<link rel="stylesheet" type="text/css" href="<?=fres?>css/main.css<?php clearCache()?>" media="all"/>
	<?php if(file_exists(fres_dir.'css/commerce.css')){?><link rel="stylesheet" type="text/css" href="<?=fres?>css/commerce.css<?php clearCache()?>" media="all"/><?php }?>
	<?php if(direction()=='rtl'){?><link rel="stylesheet" type="text/css" href="<?=fres?>css/rtl.css<?php clearCache()?>" media="all"/><?php }?>
	<link rel="stylesheet" type="text/css" href="<?=fres?>css/responsive.css<?php clearCache()?>" media="all"/>
	<?php if(!isset($noAOS)){?>
	<link rel="stylesheet" type="text/css" href="<?=fres?>css/aos.css<?php clearCache()?>" media="none" onload="this.media='all';"/>
	<?php }?>
    <script src="<?=fres?>js/plugins.js<?php clearCache()?>" defer></script>
	<?=connection('g_analytics')?>
	<?=connection('head_js')?>

</head>
	
<body>
	<div id="roller" class="hidden" class="main_color_bg">
		<img id="rolling_img" class="mid" loading="lazy" src="<?=u.'loading.gif'?>"/>
	<div id="rolling_msg" class="mid"></div>
		<div id="percentage_upload_box">
			<div id="percentage_upload_text"></div>
			<div id="percentage_upload_filler"></div>
		</div>
	</div>

	<div id="general_msg_area" style="display:none" class="hidden"></div>