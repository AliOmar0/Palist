//responsible to send the form to controller


function sub(params,roll=true,background=false) {
	return submitter(null,urlPanel,l('working..<>قيد العمل'),params,'post',false,roll,background);
}

function api(params,roll=true,background=false) {
	return submitter(null,url+'api/1.0/',l('working..<>قيد العمل'),params,'post',false,roll,background);
}


function submitter(formObject,controllerUrl,rollerMsg='loading', params, method='post',isForm=true,roll=true,background=false) {
	//disable all buttons
	if(!background)disableBtns();
	
	if(isForm==false){
	var form = document.createElement("form");
    form.setAttribute("method", method);
    form.setAttribute("action", '');
	form.setAttribute("onsubmit",'return submitter(this,urlPanel);');
	form.setAttribute("enctype", 'multipart/form-data');


    for(var key in params) {
        if(params.hasOwnProperty(key)) {
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", key);
            hiddenField.setAttribute("value", params[key]);

            form.appendChild(hiddenField);
         }
    }

    document.body.appendChild(form);
    formObject=form;
	}
	
	
	//check required file fields
	stopSub=false;
	checkFiles(formObject);
	if(stopSub==true){if(!background)enableBtns();return false;}
	//hide previous msgs, kill their timer that set in responser.js
	if (typeof msgTimeOut != "undefined" && msgTimeOut != null) clearTimeout(msgTimeOut);
	//hide previous msgs
	if(!background)hide('general_msg_area');
	//start rolling
	if(roll===true && !background){
	 start_roll(rollerMsg);
	}
	
	if (window.XMLHttpRequest) {
        var formData = new FormData(formObject);
        var xhr = new XMLHttpRequest();
        xhr.open("POST", controllerUrl + 'controller.php', true);
    }
    //the response checker
    xhr.onreadystatechange = function() {
		if (xhr.readyState == 4 && xhr.status == 200) {
			//handle response
			handleResponse(xhr.responseText,background);

			//language if supported by this module 
//				if (typeof switch_lang === "function" && !background)switch_lang();
		} //if xmlhttp responded  successfully
		else if(xhr.status == 500){
			messenger('Not specific error',3000,'Error');
		}
		
		//stop rolling
		if(!background)hide('roller');
		//dtogglebuttons
		if(!background)enableBtns();
		//reset uploader percentage
		if(percentage_upload_text!=undefined)percentage_upload_text.innerHTML='0%';
		if(percentage_upload_filler!=undefined)percentage_upload_filler.style.width='0%';
		
		//remove newly made form if !isForm
		$(form).remove();
        } //onreadystatechange, when there is a response from the handler

	//moniter uploading
	percentage_upload_text=document.getElementById('percentage_upload_text');
	percentage_upload_filler=document.getElementById('percentage_upload_filler');
	
	
	xhr.upload.addEventListener('progress', function(e) {
	var percent_complete = ~~((e.loaded / e.total)*100);
	
	// Percentage of upload completed
		if(percentage_upload_text!=undefined)percentage_upload_text.innerHTML=percent_complete+'%';
		if(percentage_upload_filler!=undefined)percentage_upload_filler.style.width=percent_complete+'%';
		
	});
	
    //Send to server
    xhr.send(formData);
	
    //to prevent form of reloading
    return false;
} //form sender main function ends here