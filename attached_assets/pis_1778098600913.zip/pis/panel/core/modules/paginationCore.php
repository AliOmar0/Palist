<?php
$row_count=getCount($m['module_prefix'],tableWhere($main_field));

if(isset($_GET['list_offset']))
	$m['items_per_page']=$_GET['list_offset'];

$page_count=(int)ceil($row_count/$m['items_per_page']);

if(isset($_GET['page_num']))$page_num=escape($_GET['page_num']);
	else $page_num=1;

$offset=($page_num-1)*$m['items_per_page'];
