<?php require 'header.php';?>

<div id="">
    <section id="internal_system_wrap" class="major_section w1200">
    <?php $_m='internal_system_8367';?>
    <h1 id="events_header"><?=l('The internal system of the syndicate<>النظام الداخلي للنقابة')?></h1>

    <!--<?php
    $resp=db($_m,NULL,NULL);
    if($resp==1) echo '<div class="no_data">'.l('No Data<>لا مُدخلات').'</div>';
    else { for($i=0;$i<count($resp);$i++){?>
    --><div class="internal_system_box in" title="<?=l($resp[$i]['title']) ?>" href="<?=url($_m,'single',$resp[$i]['id'])?>">
        
        <iframe src="<?=u.$resp[$i]['pdf_file']?>" class="pdf_file" frameborder="0"></iframe>
    <div id="pdf_butn_wrap">
    <a class="pdf_buttons in" title="<?=l($resp[$i]['title'])?>" href="<?=u.$resp[$i]['pdf_file']?>" download><?=l('Download<>تحميل')?></a>
   
    
    <!-- <a class="pdf_buttons in" target="_blank" href="<?=u.$resp[$i]['pdf_file']?>"  title="<?=l($resp[$i]['title'])?>" ><?=l('Read<>قراءة')?><a> -->
    </div>

    </div><!--
    <?php 
    }//for
    }//else
    unset($resp);?>
    -->
    </section>

</div>

<?php require 'footer.php';?>