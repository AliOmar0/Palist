<?php
$dbName='palist_legion';
$dbUser='palist_legion';
$dbPassword='U!IJ$FvY#j&!';
$conn=mysqli_connect('localhost',$dbUser,$dbPassword,$dbName);
