
<?php
if(logged(mid($_user)) ){
   
    ?>
    <script>
        window.location.href='<?=urlp('dashboard')?>';
    </script>

    <?php
}else{

?>  
        <div id="signup_wrap" class="w1200">   

        <div id="form_<?=$_user?>">
            <?php $passOnce=true;require modules_dir.$_user.'/views/add.php';?>
               <input form="<?=$_user?>" type="hidden" name="c_signup" value="<?= rand()?>"/>
               <input form="<?=$_user?>" type="submit" value="<?= l('Create Account<>عمل حساب')?>" class="b"/>
              
              <m20></m20>
              
                <a class="bd" href="<?= url('pages_1478423482','single','signin')?>" title="<?= l(detail('pages_1478423482','title','slug','login'))?>" >
                              <span class="midinline"><?= l('I have an account! Sign In<>عندي حساب، سجل دخول')?></span>
                          </a>

          </div>

    <a id="eye_icon_signup" class="po"  onclick="myFunction()"> <i>visibility_off</i></a>

    <!-- <a id="eye_icon_confirm_signup" class="po" onclick="showConfirmPassword()"> <i>visibility_off</i></a> -->
    

    <div id="c_successSignup" class="hidden">
    <?= l('The account is created and we will contact you within a few days<>تم عمل الحساب سيتم التواصل معكم خلال بضعة أيام ')?>
        
    </div>
            
           </div>
    
    <script>
    $('.<?=$_user?>_active').hide();
    function successSignup(){
      $('#form_<?=$_user?>').hide();
        $('#c_successSignup').removeClass('hidden');
       $('#eye_icon_signup').hide();
       $('#eye_icon_confirm_signup').hide();
        redirect();
    }
    </script>



    <script>

        $('#eye_icon_signup').prependTo('.joining_request_form_8371_password');

        $('#eye_icon_confirm_signup').prependTo('.joining_request_form_8371_confirm_password');
    </script>






<script>

function myFunction() {
  var x = document.getElementById("for_field_password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

// function showConfirmPassword() {
//   var x = document.getElementById("for_field_confirm_password");
//   if (x.type === "password") {
//     x.type = "text";
//   } else {
//     x.type = "password";
//   }
// }



$('.users_8400_organisation,.users_8400_business_type,.users_8400_work_nature').hide();
$('#for_field_employment_status').on('change', function () {

if ($('#for_field_employment_status').val() == '3') {

  $('.users_8400_organisation,.users_8400_business_type,.users_8400_work_nature').show();
} else {
  $('.users_8400_organisation,.users_8400_business_type,.users_8400_work_nature').hide();
}
});







</script>


<?php
}?>